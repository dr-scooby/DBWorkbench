/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;
import javax.swing.table.*;
import java.util.*;
import java.sql.*;

/**
 *
 * @author nurali
 */
public class ResultsModel extends AbstractTableModel{
    
    // Empty array of names
    private String[] columnNames = new String[0];
    
    private Vector dataRows = new Vector();
    
    
    
    public Object getValueAt(int row, int column){
        // return value at row, column
        return  ((String[]) (dataRows.elementAt(row)) )[column] ;
    }
    
    
    public int getColumnCount(){
        // return number of columns..
        return columnNames.length;
    }
    
    
    public int getRowCount(){
        // return row count, number of rows
        if(dataRows == null)
            return 0;
        else
            return dataRows.size();
    }
    
    
    public String getColumnName(int col){
        return columnNames[col] == null ? "No Name" : columnNames[col];
    }
    
    
    public void setResultSet(ResultSet rs){
        if(rs == null){
                columnNames = new String[0]; // reset column names
                if(dataRows != null)
                        dataRows.clear();//remove all entries in vector
                fireTableChanged(null); // notify table of changes
                return;
        }
        
        try{
            // get the MetaData from ResultSet
            ResultSetMetaData metada = rs.getMetaData();
            
            // get how many columns
            int numCols = metada.getColumnCount();
            System.out.println("number of columns:" + numCols);
            columnNames = new String[numCols]; // init array with number of cols
            // get column names
            for(int i = 0; i < numCols; i++){
                columnNames[i] = metada.getColumnLabel(i+1); // i + 1 because the getColumnLable starts at 1 
                System.out.println(columnNames[i]);
            }
            
            // get all the rows
            dataRows = new Vector(); // new Vector to store data
            String[] rowdata; // Stores one row
            while(rs.next()){
                rowdata = new String[numCols]; // create array to hold data
                for(int i=0; i < numCols; i++){ // for each column
                    rowdata[i] = rs.getString(i+1); // retrieve the data item
                    System.out.println(rowdata[i]);
                    
                }
                
                dataRows.addElement(rowdata); // add the row to the Vector
                
            }
            
            fireTableChanged(null); // send signal to the table there is a new model data
           
        }catch(SQLException sq){
            System.err.println(sq.getSQLState());
            System.err.println(sq.getMessage());
        }
    }
}
