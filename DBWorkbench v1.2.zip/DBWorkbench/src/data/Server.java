/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author Jahangir Ismail
 */
public class Server {
    
    private String ipaddress;
    private String dbname;
    private String username;
    private String password;
    
    
    public Server(){
        ipaddress = "" ;
        dbname = "" ;
        username   = "" ;
        password  = "" ;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public String getDbname() {
        return dbname;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public void setDbname(String dbname) {
        this.dbname = dbname;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Server{" + "ipaddress=" + ipaddress + ", dbname=" + dbname + ", username=" + username + ", password=" + password + '}';
    }
    
    
    
}
