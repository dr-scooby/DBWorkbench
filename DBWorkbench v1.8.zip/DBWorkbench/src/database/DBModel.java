
package database;
import java.sql.*;
import java.util.*;
import java.io.*;

/**
 * DBModel handles the Database connection, load drivers
 * @author Jahangir Ismail
 */
public class DBModel {
    
    private String jdbcDriver = "sun.jdbc.odbc.JdbcOdbcDriver";
    
    private String dbName = "Conacts";
    
    private String url = "jdbc:odbc:";
    
    private String driver = "com.mysql.cj.jdbc.Driver";
    private String serverip = "194.168.2.69"; // Mint VM
    private String dbname = "Skyhawk";
    private String mysqlurl = "jdbc:mysql://"+serverip+":3306/"+dbname;
    private String username = "nurali";
    private String pass = "java1973";
    
    private Connection con;
    
    private boolean connected;
    
    
    
    public DBModel(){
     
        System.out.println("starting DBModel..");
        
        try{
            Class.forName(driver);
        }catch(ClassNotFoundException e){
            System.err.println(e.getMessage());
        }
        
//         try{
//            con = DriverManager.getConnection(mysqlurl, username, pass);
//            if(con != null){
//                System.out.println("DB connected");
//                connected = true;   
//            }
//            Statement st = con.createStatement();
//            ResultSet rs = st.executeQuery("select * from contacts");
//            while(rs.next()){
//                String name = rs.getString("name");
//                String email = rs.getString("email");
//                String phone = rs.getString("phone");
//                System.out.println(name + " " + email + " " + phone);
//                System.out.println("----------------------------------------");
//            }
//            
//            Driver drive = DriverManager.getDriver(mysqlurl);
//            System.out.println("Driver major version: " + drive.getMajorVersion());
//            System.out.println("Driver minor version: " + drive.getMinorVersion()) ;
//            
//            meta(rs);
//        }catch(SQLException sql){
//            System.err.println(sql);
//        }
    }
    
    
    /**
     * connect to a server, right now only MySQL
     * @param ip
     * @param dbname
     * @param user
     * @param pass 
     */
    public void connectTo(String ip, String dbna, String user, String pass)throws SQLException{
        String mysqlurl2 = "jdbc:mysql://"+ip+":3306/"+dbna;
       
        con = DriverManager.getConnection(mysqlurl2, user, pass);
        System.out.println("Connected to DB");
        
        connected = true;
        
    }
    
    private void meta(ResultSet r){
        try{
            // get the MetaData from ResultSet
            ResultSetMetaData metada = r.getMetaData();
            
            // get how many columns
            int numCols = metada.getColumnCount();
            System.out.println("Number of Columns: " + numCols);
            for(int i = 1; i <= numCols; i++){
                System.out.println("Column: " + i);
                // print column name
                System.out.println("\tColumn: " + metada.getColumnName(i));
                System.out.println("\tLabel: " + metada.getColumnLabel(i));
                System.out.println("\tdisplay size: " + metada.getColumnDisplaySize(i));
                System.out.println("\tColumn Type: " + metada.getColumnTypeName(i));
            }
        }catch(SQLException sq){
            System.err.println(sq.getSQLState());
            System.err.println(sq.getMessage());
        }
    }
    
    // get a database Connection
    public Connection getConnection(){
        try{
            if(con == null){
           try{
            con = DriverManager.getConnection(url, username, pass);
            if(con != null)
                System.out.println("DB connected");
            }catch(SQLException sql){
                System.err.println(sql);
            } 
        }
            
        if( con.isClosed()){
            try{
            con = DriverManager.getConnection(url, username, pass);
            if(con != null)
                System.out.println("DB connected");
            }catch(SQLException sql){
                System.err.println(sql);
            } 
        }
        }catch(SQLException s){
            System.err.println(s);
        }
        
        
        
        return con;
    }
    
    
    public boolean isConnected(){
        return connected;
    }
    
    // close DB connection
    public void close()throws SQLException{
      
       if(con != null)
            con.close();
       
    }
    
}
