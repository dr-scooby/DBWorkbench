
package data;

/**
 * Profile - Server connection profile, to save profile settings
 * such as server ip address, user name, password
 * @author Jahangir
 */
public class Profile {
    
    private String profile_name;
    private String ip;
    private String username;
    private String password;
    private String dbname;
    
    /**
     * Default Constructor
     */
    public Profile(){
        profile_name = "";
        ip = "";
        username = "";
        password = "";
        dbname = "";
    }
    
    /**
     * 
     * @param profile String
     * @param ipaddress String
     * @param username String
     * @param password String
     * @param dbname  String
     */
    public Profile(String profile, String ipaddress, String username, String password, String dbname){
        this.profile_name = profile;
        this.ip = ipaddress;
        this.username = username;
        this.password = password;
        this.dbname = dbname;
    }

    
    public String getProfile_name() {
        return profile_name;
    }

    public void setProfile_name(String profile_name) {
        this.profile_name = profile_name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDbname() {
        return dbname;
    }

    public void setDbname(String dbname) {
        this.dbname = dbname;
    }

    @Override
    public String toString() {
        return profile_name + " " + ip + " " + username;
    }
    
    
    
}
